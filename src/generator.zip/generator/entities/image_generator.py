"""
Sprite/Image generation using OpenAI Responses API (gpt-image-1).

Coding style: Python 3.13+, absolute imports, built-in generics.
Reads OPENAI_API_KEY from environment via openai client.

Exports:
- generate_image(prompt: str, output_path: Path, size: str = "1024x1024", background: str = "transparent", quality: str = "high") -> Path
- generate_images(items: list, output_dir: Path, size: str = "1024x1024", background: str = "transparent", quality: str = "high", basename: str = "image", suffix: str = ".png") -> list[Path]
- generate_biome_spritesheet(output_dir: Path, size: str = "1024x1024") -> Path
- generate_token_sprites(output_dir: Path, size: str = "1024x1024") -> Path
- generate_body_bases(output_dir: Path, size: str = "1024x1024") -> Path
"""

from __future__ import annotations

import base64
import time
from pathlib import Path

from openai import OpenAI  # type: ignore


# ---------- Prompt templates ----------

BIOME_9_PROMPT = """A 2D digital illustration sprite sheet on a transparent background
containing nine hex tiles for a top‑down 2.5D RPG. Each tile is cleanly separated with
8px padding and consistent margins, arranged in a 3x3 grid. Biomes in order (row-major):
Desert, Forest, Jungle, Mountains, Ocean, Plains, Swamps, Tundra, Hills.
Style: clean line art, hand-painted textures, soft PBR-like shading, cohesive palette.
Godot-ready, no labels, no drop shadows, no bevels. Each hex fits ~300x300 inside the sheet."""

VILLAGER_TOKENS_PROMPT = """A 2D digital illustration sprite sheet on a transparent background
containing eight chess-piece-style villager tokens (silhouettes with subtle rim light), arranged
in two rows of four with equal padding: male villager, female villager, child, elder, merchant,
guard, healer, scout. Clean silhouettes, recolor-friendly flat fills with slight rim lighting.
No text, no base/platform, Godot-ready."""

BODY_BASES_PROMPT = """A 2D digital illustration sprite sheet on a transparent background containing
two neutral human body bases for a top-down 2.5D RPG (standing, front 3/4 bias). Left: masculine base.
Right: feminine base (no explicit anatomical detail). Both are clean line art with flat base color and
gentle shading. Equal padding, no text, no props. Recolor-friendly, Godot-ready."""


# ---------- Core helpers ----------

def _client() -> OpenAI:
    return OpenAI()


def _save_b64_png(image_b64: str, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(base64.b64decode(image_b64))
    return path


def _gen_png(prompt: str, size: str = "1024x1024", quality: str = "high", background: str = "transparent") -> bytes:
    client = _client()
    response = client.responses.create(
        model="gpt-4.1",
        input=[{
            "role": "user",
            "content": [{"type": "input_text", "text": prompt}],
        }],
        tools=[{
            "type": "image_generation",
            "background": background,
            "quality": quality,
            "size": size,
        }],
    )
    calls = [o for o in response.output if getattr(o, "type", "") == "image_generation_call"]
    if not calls:
        raise RuntimeError("No image data returned from image generation call.")
    image_b64 = calls[0].result  # base64-encoded image
    return base64.b64decode(image_b64)


def _retry_bytes(fn, retries: int = 3, delay: float = 1.5) -> bytes:
    last_err: Exception | None = None
    for i in range(retries):
        try:
            return fn()
        except Exception as e:
            last_err = e
            time.sleep(delay)
    assert last_err is not None
    raise last_err


# Generic image generation for arbitrary prompts (used by MCP server)


def generate_image(prompt: str, output_path: Path, size: str = "1024x1024", background: str = "transparent", quality: str = "high") -> Path:
    """Generate a single PNG image using the Responses API and write it to `output_path`.

    Returns the `output_path`.
    """
    png = _retry_bytes(lambda: _gen_png(prompt, size=size, quality=quality, background=background))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(png)
    return output_path



def generate_images(
    items: list,
    output_dir: Path,
    size: str = "1024x1024",
    background: str = "transparent",
    quality: str = "high",
    basename: str = "image",
    suffix: str = ".png",
) -> list[Path]:
    """Batch-generate images.

    Accepts one of the following for *items*:
    - list[str]: prompts. Files will be named f"{basename}_{i+1}{suffix}".
    - list[tuple[str, str]]: (prompt, filename) pairs. *filename* may include extension; if not, *suffix* is appended.
    - list[dict]: each with keys: ``prompt`` (required) and optional ``filename``, ``size``, ``background``, ``quality``.

    Returns the list of written Paths.
    """
    paths: list[Path] = []
    output_dir.mkdir(parents=True, exist_ok=True)

    def _resolve_item(idx: int, item):
        # Normalize to (prompt, filepath, local_size, local_bg, local_quality)
        local_size = size
        local_bg = background
        local_quality = quality

        if isinstance(item, str):
            prompt = item
            filename = f"{basename}_{idx+1}{suffix}"
        elif isinstance(item, tuple) and len(item) == 2:
            prompt, filename = item
        elif isinstance(item, dict):
            prompt = item.get("prompt", "").strip()
            if not prompt:
                raise ValueError("dict item missing non-empty 'prompt'")
            filename = item.get("filename")
            local_size = item.get("size", local_size)
            local_bg = item.get("background", local_bg)
            local_quality = item.get("quality", local_quality)
        else:
            raise TypeError("items must be list[str] | list[tuple[str,str]] | list[dict]")

        if not filename:
            filename = f"{basename}_{idx+1}{suffix}"
        elif suffix and not any(filename.lower().endswith(ext) for ext in (".png", ".jpg", ".jpeg", ".webp")):
            filename = f"{filename}{suffix}"

        return prompt, output_dir / filename, local_size, local_bg, local_quality

    for i, item in enumerate(items):
        prompt, path, s, bg, q = _resolve_item(i, item)
        png = _retry_bytes(lambda: _gen_png(prompt, size=s, background=bg, quality=q))
        path.write_bytes(png)
        paths.append(path)

    return paths



# ---------- Public API ----------

def generate_biome_spritesheet(output_dir: Path, size: str = "1024x1024") -> Path:
    out = output_dir / "biomes_9_hex.png"
    png = _retry_bytes(lambda: _gen_png(BIOME_9_PROMPT, size=size, background="transparent"))
    out.write_bytes(png)
    return out


def generate_token_sprites(output_dir: Path, size: str = "1024x1024") -> Path:
    out = output_dir / "tokens_8_villagers.png"
    png = _retry_bytes(lambda: _gen_png(VILLAGER_TOKENS_PROMPT, size=size, background="transparent"))
    out.write_bytes(png)
    return out



def generate_body_bases(output_dir: Path, size: str = "1024x1024") -> Path:
    out = output_dir / "body_bases_2.png"
    png = _retry_bytes(lambda: _gen_png(BODY_BASES_PROMPT, size=size, background="transparent"))
    out.write_bytes(png)
    return out


# ---------- Category registry (for MCP server) ----------

from typing import Callable

def _not_implemented_category(*args, **kwargs):
    raise NotImplementedError("This image category is not implemented yet.")

# Map human-friendly category names to generator callables.
# The MCP server can use this table to discover what's available.
IMAGE_CATEGORIES: dict[str, Callable[..., Path]] = {
    "biomes": generate_biome_spritesheet,
    "tokens": generate_token_sprites,
    "bodies": generate_body_bases,
    # Planned categories; present so imports work, but will raise a clear error if called:
    "items": _not_implemented_category,
    "maps": _not_implemented_category,
    "ui": _not_implemented_category,
}

def get_category_names() -> list[str]:
    """Return the list of available/known image categories."""
    return list(IMAGE_CATEGORIES.keys())

__all__ = [
    "generate_image",
    "generate_images",
    "generate_biome_spritesheet",
    "generate_token_sprites",
    "generate_body_bases",
    "IMAGE_CATEGORIES",
    "get_category_names",
]
