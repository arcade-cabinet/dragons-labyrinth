# Dragon's Labyrinth — Replit Handoff Package

This archive contains the complete design and narrative documentation for **Dragon’s Labyrinth**.  It is intended as a comprehensive hand‑off to Replit, which will act as the sole developer and orchestrator of the game.  There is no separate generator; instead, the documents, YAML definitions and scripts here describe the world, characters, quests and asset cues in a way that Replit can directly interpret and implement.

## Contents

* **narrative_design.md** – a high‑level overview of the game’s emotional arc, biomes, systems and vision.
* **companions.yaml** – definitions of each companion, their story arcs and dialogue across stages.
* **monsters.yaml** – descriptions of enemy types and bosses, including behaviours and asset cues.
* **quests.yaml** – a set of sample quests spanning all stages, with branch decisions and consequences.
* **biomes.md** – details of each biome and how it evolves through the stages, including asset and audio cues.
* **bosses.md** – deeper descriptions of the stage bosses and the narrative/choice structure of their encounters.
* **dialogues.md** – examples of NPC and companion dialogues at each stage.
* **scripts/forsaken_knight_blender.py** – a Blender script to generate a low‑poly “Forsaken Knight” model on a hex base; intended as a starting point for other Blender assets.

Each file should be read and interpreted by Replit as part of its role as director, developer and asset pipeline.  All decisions made by the original generator are now explicitly articulated here.