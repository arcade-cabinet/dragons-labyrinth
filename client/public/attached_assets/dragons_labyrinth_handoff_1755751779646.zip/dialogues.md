# Dialogue Samples

The following dialogue snippets illustrate NPC and companion speech across the stages.  They are intended to guide voice tone and content; Replit should generate additional lines following these patterns.

## Peace

* **Villager** – "Beautiful day, isn't it? The fields have never been greener."
* **Merchant** – "Fresh bread! Get your fresh bread! Oh, you're delivering some? Thank you for your help."
* **Child** – "Do you want to play? We found a frog!"

## Unease

* **Townsperson** – "Have you noticed? The birds... they've stopped singing."
* **Old Woman** – "I heard whispers last night. They spoke of the dragon. Foolish tales... perhaps."
* **Companion (Einar)** – "Did you hear that whisper? Probably just the wind... right?"

## Dread

* **Swamp Hermit** – "Gold? Worthless now. The only currency is how long you can run."
* **Former Guard** – "I locked the gates... it didn't matter. They came anyway."
* **Companion (Tamara)** – "I can't sleep. The shadows have teeth."

## Terror

* **Ghost Town Echo** – "Help... me... we should have never come. Help..."
* **Traitor Companion** – "You left them! You always leave them! Now it's your turn."
* **Companion (Sorin)** – "Forgive me. Knowledge must be attained, no matter the cost."

## Horror

* **Labyrinth Voice** – "Turn back... or face yourself."
* **Dragon** – "You have walked so far to find what was always inside you."
* **Companion (Echo)** – "Are you sure this is the end? Is there an end?"