# Bosses of Dragon’s Labyrinth

## Hollow Caretaker (Stage 1 – Unease)

**Appearance** – An old man with sunken eyes, holding a lantern that emits no light.  His skin hangs from his bones, and his voice is stuck in loops.

**Encounter** – The Hollow Caretaker appears near the village well or at the crypt outskirts, asking repetitive questions and referencing events from Peace.  Approaching him triggers a boss encounter.

**Behaviour**

* Moves slowly, swinging his lantern to emit damaging pulses of darkness.
* Repeats lines from villagers in Peace, causing confusion.
* Summons Whispering Shades that distract the player.

**Choices**

1. **Persuade** – Engage in dialogue, soothing him with memories.  This frees his soul, and he reveals information about the labyrinth’s entrance.  Companions gain a temporary morale boost.
2. **Kill** – Attack and defeat him.  He drops a cursed lantern that lights your path but whispers ceaselessly.  Companions lose morale.

## Forsaken Knight (Stage 2 – Dread)

**Appearance** – A low‑poly knight bound in rusted armour.  His helm is cracked, revealing emptiness inside.  He wields a heavy sword and a shield with heraldry long faded.  A torn cape flutters behind him.

**Encounter** – Found within the abandoned fort or ruins.  He patrols a corridor, repeating vows of protection.  Approaching triggers a duel.

**Behaviour**

* Alternates between slow, powerful swings and shield bashes.
* Breaks into lament between attacks, hinting at his backstory.
* His armour falls apart as the fight progresses, revealing ghostly light.

**Choices**

1. **Empathy** – Sheathe your weapon and listen.  He recounts his failure to protect his family from the dragon.  Freeing him grants you a relic that restores sanity but pulls the dragon closer.
2. **Brutality** – Attack and defeat him.  You obtain his armour, which increases defence but continuously whispers, causing hallucinations.

**Blender Script** – See `scripts/forsaken_knight_blender.py` for a ready‑to‑run script to model his figure.

## Traitor Companion (Stage 3 – Terror)

**Appearance** – One of your companions now twisted by the dragon’s influence: their model darkens, geometry warps, eyes glow with unnatural light.

**Encounter** – During a moral choice quest, the companion attacks the player and the party.

**Behaviour**

* Uses abilities learned earlier (healing, spells, melee) now turned lethal.
* Calls out the player’s past decisions, inflicting sanity damage.
* At half health, the companion may hesitate, providing an opportunity to forgive.

**Choices**

1. **Forgive** – Spare the traitor.  They regain some sanity, helping you in the labyrinth and unlocking the Understanding ending.  Other companions may distrust you.
2. **Execute** – Kill them.  You gain an immediate boost but lose the possibility of the Understanding ending.

## The Dragon (Stage 4 – Horror)

**Appearance** – A massive serpentine creature coiling through the labyrinth.  Only parts of its body are visible at any one time: a clawed talon here, an eye the size of a doorway there.  Its scales blend into the stone.

**Encounter** – In the labyrinth’s heart.  The dragon speaks telepathically, reflecting your journey.

**Behaviour**

* Stalks using sound; players must rely on audio cues to avoid sudden attacks.
* Alters labyrinth layout dynamically, blocking or opening paths.
* During the final confrontation, the dragon does not attack directly but presents choices.

**Choices**

1. **Acceptance** – Step toward the dragon and allow yourself to be consumed.  The cycle continues, and the world forgets you.
2. **Defiance** – Hurl yourself into the pit, denying the dragon your essence.  You die, preventing the dragon’s victory.
3. **Understanding** – Engage the dragon in dialogue, decipher the truth of its existence and your choices.  Free all trapped souls, end the cycle and release the dragon.