# Biomes of Dragon’s Labyrinth

Dragon’s Labyrinth progresses through a set of biomes that evolve as dread deepens.  Each entry below includes physical description, colour palette, asset cues for models and audio suggestions for day and night.  Replit should use these cues when generating geometry, textures and ambience.

## Peace Stage Biomes

### Grasslands
- **Appearance** – Rolling hills of green, dotted with flowers and gentle streams.  Simple wooden fences and windmills.
- **Colours** – Bright greens, blues and yellows.
- **Models** – Hex tiles with grass blades, low‑poly cows and sheep, windmill props.
- **Audio** – Morning birdsong and gentle breeze.

### Village
- **Appearance** – Clusters of timber houses, thatched roofs, cobblestone paths, markets with colourful cloths.
- **Colours** – Warm browns, oranges and reds.
- **Models** – Simple houses, stalls with produce, carts.
- **Audio** – Bustling chatter, laughter, clanking pots.

### Market
- **Appearance** – An open square with vendors selling goods under fabric canopies.
- **Colours** – Vibrant fabric patterns, bright fruits.
- **Models** – Market stalls, barrels, crates and produce displays.
- **Audio** – Haggling voices, clinking coins, running children.

### Farmland
- **Appearance** – Rows of crops, scarecrows, tools and irrigation channels.
- **Colours** – Lush greens, earthy browns and golden crops.
- **Models** – Hex tiles with tilled soil patterns, scarecrows and ploughs.
- **Audio** – Croaking frogs, distant dog barks and creaking wheels.

## Unease Stage Biomes

### Forest
- **Appearance** – Dense trees with long shadows; light filtered through leaves.
- **Colours** – Darker greens and muted browns with shafts of light.
- **Models** – Tree variations (deciduous, coniferous), rocks and underbrush.
- **Audio** – Rustling leaves, occasional whispers, distant caws.

### Town
- **Appearance** – Larger buildings of stone and plaster, now with windows shuttered.
- **Colours** – Greys and faded pastels.
- **Models** – Stone cottages, closed shops, a well in the centre.
- **Audio** – Creaking signs, murmur of unseen voices, wind whistling.

### Crypt Outskirts
- **Appearance** – The border of a graveyard; moss‑covered tombstones, dead trees and low fog.
- **Colours** – Greys, moss greens and pale whites.
- **Models** – Tombstones with engravings, dead bushes and small statues.
- **Audio** – Distant chants, soft weeping, wind through stones.

## Dread Stage Biomes

### Swamp
- **Appearance** – Murky waters with rotting trees and slimy roots; fog clings to the surface.
- **Colours** – Muddy browns, sickly greens and dark water.
- **Models** – Water tiles with lily pads, rotting logs and leeches.
- **Audio** – Croaks, buzzing insects, occasional splash.

### Ruins
- **Appearance** – Crumbling stone buildings overtaken by nature; collapsed walls.
- **Colours** – Greys, moss greens and deep shadows.
- **Models** – Broken columns, arches and toppled statues.
- **Audio** – Dripping water, distant metal clangs, echoing footsteps.

### Abandoned Fort
- **Appearance** – Large stone fortification, gates ajar, banners torn and faded.
- **Colours** – Dark stone, rusted metal and weathered wood.
- **Models** – Battlements, broken ballistas and overturned carts.
- **Audio** – Clanging chains, wind howling through open halls and faint battle cries.

### Cavern
- **Appearance** – Dark caves lit by phosphorescent crystals; stalactites and stalagmites.
- **Colours** – Deep blues, purples and glowing greens.
- **Models** – Rock formations, pools and crystals.
- **Audio** – Dripping water, echoes and muffled roars from deeper within.

## Terror Stage Biomes

### Ghost Town
- **Appearance** – A deserted settlement where time seems frozen; objects float and distort.
- **Colours** – Greyscale with occasional bursts of saturated colour, glitch‑like effects.
- **Models** – Warped houses, flickering lights and chairs floating.
- **Audio** – Overlapping conversations, child's laughter turning into a scream.

### Warped City
- **Appearance** – Tall structures lean at impossible angles; roads twist and loop.
- **Colours** – Cold whites, dark blues and occasional neon streaks.
- **Models** – Bending towers, floating platforms and fractured bridges.
- **Audio** – Hum of unknown machines, distant traffic, murmured prayers.

### Mirror Lake
- **Appearance** – Still water that reflects not reality but alternate, sometimes horrifying scenes.
- **Colours** – Silver, black with iridescent hints.
- **Models** – Water tiles with reflective surfaces, rocks jutting out, will‑o‑wisps.
- **Audio** – Splashes, whispered echoes, distant wails reversed.

### Labyrinth Outskirts
- **Appearance** – Tall hedges of dark stone, corridors that subtly shift; carvings of eyes and dragons.
- **Colours** – Black, dark green with hints of luminescent runes.
- **Models** – Walls with carvings, gates, torches that flicker.
- **Audio** – Low hum, shuffling feet, dragon’s breath from far away.

## Horror Stage Biomes

### Labyrinth Core
- **Appearance** – Endless stone corridors with shifting walls, stairways leading nowhere, surreal geometry.
- **Colours** – Monochrome greys and blacks with subtle red veins.
- **Models** – Stone tiles, shifting wall segments and doorways appearing and disappearing.
- **Audio** – Heartbeats, drips, distant growls and laboured breathing.

### Dragon’s Chamber
- **Appearance** – A vast cavern with a bottomless pit and tall pillars; a faint glow reveals glimpses of the dragon’s massive form.
- **Colours** – Dark reds, oranges and deep shadows.
- **Models** – Huge pillars, piles of bones and scales embedded in stone.
- **Audio** – Deep breathing, rumbling earth, occasional whispers that are clearly the dragon’s voice.

### Final Vision
- **Appearance** – An ethereal space where the protagonist confronts their choices; scenes from past stages fade in and out.
- **Colours** – Soft whites, translucent blues and shimmering silver.
- **Models** – Floating platforms, fragments of memory, silhouettes of companions.
- **Audio** – Layered voices of companions, wind chimes and the dragon's voice merging with the player’s inner monologue.